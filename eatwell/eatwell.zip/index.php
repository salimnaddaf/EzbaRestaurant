<?php

$name = $_POST['name'];

$visitor_email = $_POST['email'];

$message = $_POST['message'];

?>

<!DOCTYPE html>
<html lang="en">
<link rel = "icon"
href = "images/semel12.png"
type="image/png">
  <head>

    <title>Ezba Restaurant</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700|Raleway" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">



    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body data-spy="scroll" data-target="#site-navbar" data-offset="200">

    <nav class="navbar navbar-expand-lg navbar-dark site_navbar bg-dark site-navbar-light" id="site-navbar">
      <div class="container">
        <a class="navbar-brand" href="index.php">Ezba</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#site-nav" aria-controls="site-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="site-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="#section-home" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="#section-about" class="nav-link">About</a></li>
            <li class="nav-item"><a href="#section-offer" class="nav-link">Offer</a></li>
            <li class="nav-item"><a href="ezbamenuo.html" class="nav-link">Menu</a></li>
            <li class="nav-item"><a href="#section-news" class="nav-link">News</a></li>
            <li class="nav-item"><a href="#section-gallery" class="nav-link">Gallery</a></li>
            <li class="nav-item"><a href="#section-contact" class="nav-link">Contact</a></li>
              <li class="nav-item"><a href="admin.html" class="nav-link">LogIn</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <section class="site-cover" style="background-image: url(images/tb12.jpg);" id="section-home">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center site-vh-100">
          <div class="col-md-12">
            <h1 class="site-heading site-animate mb-3">Welcome To Ezba Restaurant</h1>
          <b>   <h2 class="h5 site-subheading mb-5 site-animate">Come and eat well with our delicious &amp; homemade arabic healthy foods.</h2></b>
            <p><a href="https://colorlib.com/" target="_blank" class="btn btn-outline-white btn-lg site-animate" data-toggle="modal" data-target="#reservationModal">הזמנות שולחן</a></p>
          </div>
        </div>
      </div>
    </section>
    <!-- END section -->

    <section class="site-section" id="section-about">
      <div class="container">
        <div class="row">
          <div class="col-md-5 site-animate mb-5">
            <h4 class="site-sub-title">הסיפר שלנו</h4>
            <h2 class="site-primary-title display-4">ברוכאים הבאים</h2>
            <p>מסעדת עזבה נפתחה על ידי משפחת דאוד – חביב, מינרבה רעייתו והילדים, בזמן שחביב משתוקק להקים לתחייה את המטבח של משפתחו שהגיעה לפני כ- 200 שנה מצידון אשר בלבנון. בעזבה תשמחו לגלות .</p>

            <p class="mb-4">מסעדת עזבה</p>
            <p><a href="#" class="btn btn-secondary btn-lg">Learn More About Us</a></p>
          </div>
          <div class="col-md-1"></div>
          <div class="col-md-6 site-animate img" data-animate-effect="fadeInRight">
            <img src="images/hm12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
          </div>
        </div>
      </div>
    </section>
    <!-- END section -->


    <section class="site-section bg-light" id="section-offer">
      <div class="container">

        <div class="row">
          <div class="col-md-12 text-center mb-5 site-animate">
            <h4 class="site-sub-title">ההצעות שלנו</h4>
            <h2 class="display-4">תבשילים עונתיים שלנו</h2>
            <div class="row justify-content-center">
              <div class="col-md-7">
                <p class="lead">מסעדת עזבה מכפר ראמה מציגה בגאווה את המטבח הערבי, הביתי והאותנטי, המסתמך בלעדית על חומרי הגלם העונתיים.</p>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <div class="owl-carousel site-owl">

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/mlo5ia12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">מלוכיה</h5>
                    <p class="mb-4">תבשיל זה כולל את עלי המלוכיה אשר מבושלים על בסיס ציר עוף ביחד עם שום ומוגשים בתוספת אורז בצד.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/bamia12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">תבשיל באמיה </h5>
                    <p class="mb-4">אצבעות באמיה מטוגנות ומבושלות ברוטב עגבניות ומגיעות עם אורז לבן ואטריות.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/3akob12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">עכובית גלגל</h5>
                    <p class="mb-4">קוץ בר שמורידים לו את הקוצים ומבשלים את זה עם גרגרי חומוס ובצל. מוגש עם אורז בצד.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/mlo5ia12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">מלוכיה</h5>
                    <p class="mb-4">תבשיל זה כולל את עלי המלוכיה אשר מבושלים על בסיס ציר עוף ביחד עם שום ומוגשים בתוספת אורז בצד.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/bamia12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">תבשיל באמיה </h5>
                    <p class="mb-4">אצבעות באמיה מטוגנות ומבושלות ברוטב עגבניות ומגיעות עם אורז לבן ואטריות.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/3akob12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">עכובית גלגל</h5>
                    <p class="mb-4">קוץ בר שמורידים לו את הקוצים ומבשלים את זה עם גרגרי חומוס ובצל. מוגש עם אורז בצד.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/mlo5ia12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">מלוכיה</h5>
                    <p class="mb-4">תבשיל זה כולל את עלי המלוכיה אשר מבושלים על בסיס ציר עוף ביחד עם שום ומוגשים בתוספת אורז בצד.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/bamia12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">תבשיל באמיה </h5>
                    <p class="mb-4">אצבעות באמיה מטוגנות ומבושלות ברוטב עגבניות ומגיעות עם אורז לבן ואטריות.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

              <div class="item">
                <div class="media d-block mb-4 text-center site-media site-animate border-0">
                  <img src="images/3akob12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
                  <div class="media-body p-md-5 p-4">
                    <h5 class="text-primary"> 35 points</h5>
                    <h5 class="mt-0 h4">עכובית גלגל</h5>
                    <p class="mb-4">קוץ בר שמורידים לו את הקוצים ומבשלים את זה עם גרגרי חומוס ובצל. מוגש עם אורז בצד.</p>

                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">הזמן!</a></p>
                  </div>
                </div>
              </div>

    </section>
    <!-- END section -->


    <!-- END section -->

    <section class="site-section bg-light" id="section-news">
      <div class="container">

        <div class="row">
          <div class="col-md-12 text-center mb-5 site-animate">
            <h2 class="display-4">חדשות</h2>
            <div class="row justify-content-center">
              <div class="col-md-7">
                <p class="lead"> מגוון שירותים הנמצאים גם כן במסעדה.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="media d-block mb-4 text-center site-media site-animate">
              <img src="images/sdna12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
              <div class="media-body p-md-5 p-4">
                <h5 class="mt-0 h4">סדנאות אוכל</h5>
                <p class="mb-4">המסעדה מציעה תפריט נפלא של אוכל ביתי, מאופיין בעדינותו ובריאותו. בואו ללמוד איך להכין אותו! במסעדת עזבה נערכות סדנאות בישול באווירה משפחתית וכיפית. סדנת הבישול מועברת על ידי הבעלים והטבחים של מסעדת עזבה, מנירווה וחביב דאוד.</p>

                <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">Read More</a></p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="media d-block mb-4 text-center site-media site-animate">
              <img src="images/ke12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
              <div class="media-body p-md-5 p-4">
                <h5 class="mt-0 h4">קייטרינג</h5>
                <p class="mb-4">הזמנת קייטרינג לאירועים מיוחדים לפי התאמה אישית.</p>

                <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">Read More</a></p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 col-sm-6">
            <div class="media d-block mb-4 text-center site-media site-animate">
              <img src="images/hr12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
              <div class="media-body p-md-5 p-4">
                <h5 class="mt-0 h4">הרצאות על המטבח הערבי</h5>
                <p class="mb-4">אנו מציעים מגוון הרצאות על המטבח הערבי וההיסטוריה שלו אשר מועברות ישירות על ידי בעל הבית והטבח שלנו, חביב דאוד.</p>

                <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">Read More</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- END section -->

    <section class="site-section" id="section-gallery">
      <div class="container">
        <div class="row site-custom-gutters">

          <div class="col-md-12 text-center mb-5 site-animate">
            <h2 class="display-4">גלרית תמונות</h2>
            <div class="row justify-content-center">
              <div class="col-md-7">
                <p class="lead">כאן תוכלו לצפות בטעימה מכל המנות הנפלאות שאנו מגישים בעזבה.</p>
              </div>
            </div>
          </div>

          <div class="col-md-4 site-animate">
            <a href="images/dishes/1.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/1.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/2.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/2.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/3.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/3.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>

          <div class="col-md-4 site-animate">
            <a href="images/dishes/4.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/4.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/5.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/5.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/6.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/6.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/7.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/7.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/8.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/8.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/9.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/9.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>

          <div class="col-md-4 site-animate">
            <a href="images/dishes/10.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/10.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/11.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/11.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 site-animate">
            <a href="images/dishes/12.jpg" class="site-thumbnail image-popup">
              <img src="images/dishes/12.jpg" alt="Free Template by colorlib.com" class="img-fluid">
            </a>
          </div>

        </div>
      </div>
    </section>
    <!-- END section -->

    <section class="site-section bg-light" id="section-contact">
      <div class="container">
        <div class="row">

          <div class="col-md-12 text-center mb-5 site-animate">
            <h2 class="display-4">יצירת קשר</h2>
            <div class="row justify-content-center">
              <div class="col-md-7">
                <p class="lead">נשמח לעמוד לרשותכם לכל בקשה,תלונה ,המלצה או אפילו לשיחה טובה על אוכל :)</p>
              </div>
            </div>
          </div>

          <div class="col-md-7 mb-5 site-animate">
            <form action="form-to-email.php" method="post" enctype="text/plain">
              <div class="form-group">
                <label for="name" class="sr-only">Name</label>
                <input type="text" class="form-control" id="name" placeholder="Name">
              </div>
              <div class="form-group">
                <label for="email" class="sr-only">Email</label>
                <input type="text" class="form-control" id="email" placeholder="Email">
              </div>
              <div class="form-group">
                <label for="message" class="sr-only">Message</label>
                <textarea name="message" id="message" cols="30" rows="10" class="form-control" placeholder="Write your message"></textarea>
              </div>
              <div class="form-group">
                <input type="submit" class="btn btn-primary btn-lg" value="שלח">
              </div>

            </form>

          </div>
          <div class="col-md-1"></div>
          <div class="col-md-4 site-animate">
            <p><img src="images/tb12.jpg" alt="" class="img-fluid"></p>
            <p class="text-black">
              כתובת: <br> צומת ראמה מערב. כביש 85<br>  ישראל <br> <br>
              טלפון: <br> 04-9888808 <br> <br>
              Email: <br> <a href="">ezba@restatezba.com</a>
            </p>

          </div>

        </div>
      </div>
    </section>

    <div  style="width:100%;height:500px; background-image: url(images/map12.png);"align="middle">
      <div class="showtheway">
        <a href="https://showtheway.io/to/32.936963,35.357286?name=%D7%A2%D7%96%D7%91%D7%94" target="_blank" title="Show the Way to עזבה with your favorite navigation application">Show the Way</a></div>
      <script src="https://showtheway.io/w.js" async="async" type="text/javascript"></script>
  </div>
     </div>


    <!-- END section -->


    <footer class="site-footer site-bg-dark site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-4 site-animate">
                <h2 align="right" class="site-heading-2">עלינו</h2>
                <p align="right">
מסעדת עזבה מכפר ראמה מציגה בגאווה את המטבח הערבי, הביתי והאותנטי, המסתמך בלעדית על חומרי הגלם העונתיים. בקיץ יוגשו לשולחנות במיה ומלוחיה וכמובן עלי גפן ממולאים. בסתיו יופיעו הקטניות המיובשות ואל תוך העונה הקרה יופיעו במטבח בזה אחר זה צמחי הבר כמו עולש, חובזה, עכוב ושמיר בר.</p>
              </div>
                <div class="col-md-1"></div>
              <div class="col-md-2 site-animate">
                <div class="site-footer-widget mb-4">

                  <h2  align="right" class="site-heading-2">&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; The Restaurant</h2>
                  <ul class="list-unstyled">
                    <li><a align="right" href="#section-about" class="py-2 d-block">About Us</a></li>

                    <li><a align="right" href="#section-contact" class="py-2 d-block">Contact</a></li>
                  </ul>



                </div>
              </div>


            </div>
          </div>

        </div>
        <div class="row site-animate">
           <div class="col-md-12 text-center">
            <div class="site-footer-widget mb-4">
              <ul class="site-footer-social list-unstyled ">

                <li class="site-animate"><a href="https://www.facebook.com/ezba.rest/"><span class="icon-facebook"></span></a></li>
                <li class="site-animate"><a href="https://www.instagram.com/ezbarestaurant/"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>



        </div>
      </div>
    </footer>




    <!-- Modal -->
    <div class="modal fade" id="reservationModal" tabindex="-1" role="dialog" aria-labelledby="reservationModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <div class="row">
              <div class="col-lg-12">
                <div class="bg-image" style="background-image: url(images/tb12.jpg);"></div>
              </div>
              <div class="col-lg-12 p-5">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <small>CLOSE </small><span aria-hidden="true">&times;</span>
                </button>
                <h1 class="mb-4">הזמנת שולחן</h1>
                <form action="#" method="post">
                  <div class="row">
                    <div class="col-md-6 form-group">
                      <label for="m_fname">שם פרטי</label>
                      <input type="text" class="form-control" id="m_fname">
                    </div>
                    <div class="col-md-6 form-group">
                      <label for="m_lname">שם משפחה</label>
                      <input type="text" class="form-control" id="m_lname">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12 form-group">
                      <label for="m_email">איימיל</label>
                      <input type="email" class="form-control" id="m_email">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 form-group">
                      <label for="m_people">כמות אנשים</label>
                      <select name="" id="m_people" class="form-control">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4+">4+</option>
                      </select>
                    </div>
                    <div class="col-md-6 form-group">
                      <label for="m_phone">מספר פלאפון</label>
                      <input type="text" class="form-control" id="m_phone">
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6 form-group">
                      <label for="m_date">תאריך</label>
                      <input type="text" class="form-control" id="m_date">
                    </div>
                    <div class="col-md-6 form-group">
                      <label for="m_time">שעה</label>
                      <input type="text" class="form-control" id="m_time">
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-12 form-group">
                      <label for="m_message">תוכן</label>
                      <textarea class="form-control" id="m_message" cols="30" rows="7"></textarea>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-12 form-group">
                      <input type="submit" class="btn btn-primary btn-lg btn-block" value="הזמן עכשיו">
                    </div>
                  </div>

                </form>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

    <!-- END Modal -->

    <!-- loader -->
    <div id="site-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>

    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>

    <script src="js/jquery.animateNumber.min.js"></script>


    <script type="text/javascript" src="css/jquery/map.js" id="msgjsext_map"></script>
    <script src="js/google-map.js"></script>

    <script src="js/main.js"></script>


  </body>
</html>
